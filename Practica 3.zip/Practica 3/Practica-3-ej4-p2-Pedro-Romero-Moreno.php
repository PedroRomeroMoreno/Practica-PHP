﻿<?php
	//obtener datos del formulario
	$nombre= $_POST['nombre'];
	$trabajo = $_POST['trabajo'];
	$telefono = $_POST['telefono'];
	$dire = $_POST['dire'];
	$otro = $_POST['otro'];
	//control de errores
	//Comprobar si el archivo exite y si no existe crearlo
	$archivo = 'contactos.txt';
	if(!file_exists($archivo)) {
		fopen($archivo,'w'); //crea el archivo vacio
	}
	//Abrir el archivo en modo escritura y añadir los datos
	$file= fopen($archivo,'a');
	fwrite($file,"Contacto:$nombre $trabajo $telefono $dire $otro".PHP_EOL);
	fclose($file);
	echo"<form method='post' action='contactos.txt'>
	<input type='submit' value='Mostrar datos'>
	</form>
	";
	
?>
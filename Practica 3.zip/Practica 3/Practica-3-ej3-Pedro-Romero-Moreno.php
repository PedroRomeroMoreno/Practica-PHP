<!DOCTYPE html>
<html>
	<head>
	<title> Practica php ej3 formulario</title>
	<meta charset="UTF-8">
	</head>
	<body>
	<fieldset>
	<h2>DATOS DEL ALUMNO</h2>
	<form method="post" action="Practica-3-ej3-p2-Pedro-Romero-Moreno.php">
	Introduzca su nombre:<input type="text" name="nombre" required><br>
	Introduzca su telefono:<input type="text" name="telefono" required>
	Matriculado<input type="checkbox" value="si" name="matricula"><br>
	Mostrar datos:<select name="mostrar">
	<option value="pantalla">Por pantalla
	<option value="archivo">En archivo datos.txt
	</select>
	<div>
	Enseñanza:
	<p><input type="radio" value="Secundaria" name="edu">Secundaria
	<input type="radio" value="Bachillerato" name="edu">Bachillerato</p>
	<p><input type="radio" value="Ciclo Medio" name="edu">Ciclo Medio
	<input type="radio" value="Ciclo Superior" name="edu">Ciclo Superior</p>
	</fieldset>
	<input type="submit" value="Enviar datos">
	</form>
</html>

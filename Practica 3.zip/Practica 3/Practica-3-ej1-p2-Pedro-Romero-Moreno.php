<body>
<?php
	$alto=0;
	$ancho=0;
	$alto=$_REQUEST['alto'];
	$ancho=$_REQUEST['ancho'];
	if((($alto<=0)or($ancho<=0)) or (($alto>101)or($ancho>101))){
		echo"Inserte los dos numeros,que sean mayores que uno y menores que ciento uno.<br>";
	}else{
	print "Alto: $alto</br>";
	print "Ancho: $ancho</br>";
	for ($i=0;$i<$alto;$i++){
		print"</br>";
		for ($l=0;$l<$ancho;$l++){
			print "* ";
		}
		}
	}
?>
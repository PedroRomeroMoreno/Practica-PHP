<html>
	<body>
	<form action="Practica-3-ej4-p4-Pedro-Romero-Moreno.php" method="post">
	Nombre:<input type="text" name="nombre"><br>
	<input type="submit" value="Aceptar">
	</form>
	
	</body>
</html>
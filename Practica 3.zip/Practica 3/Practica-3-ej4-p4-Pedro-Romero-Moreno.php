<body>
<?php
	$nombre=$_REQUEST['nombre'];
	//hacer las comprobaciones
	$fichero="contactos.txt";
	$fd= fopen($fichero,"r"); //Modo r,read
	$v= 0;
	while(!feof($fd)){
		$linea =fgets($fd);
		if (strpos($linea, "Contacto:$nombre") !== false){
			echo  " $linea";
			$v=1;
			end;
		}
	}
	if ($v == 0){
		echo "El nombre $nombre no corresponde a ningun contacto";
	
	}
?>
</body>
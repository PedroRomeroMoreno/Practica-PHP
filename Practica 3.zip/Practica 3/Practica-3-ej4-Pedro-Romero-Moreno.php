﻿<html>
<head>
<title>Pratica 3 ej4 Pedro RM</title>
</head>
<body>
<h2>Agenda Virtual PHP</h2>
<h1>Contactos</h1>
Para guardar presione el boton<br>
<form method="post" action="Practica-3-ej4-p2-Pedro-Romero-Moreno.php">
Nombre:<input type="text" name="nombre" required><br>
Trabajo:<input type="text" name="trabajo" required><br>
Telefono:<input type="text" name="telefono" required><br>
Dirección:<input type="text" name="dire" required><br>
Otras:<input type="text" name="otro" required><br>
<input type="submit" value="Guardar"><input type="reset" value="Reset">
</form>
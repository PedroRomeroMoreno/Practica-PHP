<!DOCTYPE html>
<html>
	<head>
	<title> Practica php ej2</title>
	<meta charset="UTF-8">
	</head>
	<body>
	<?php
	echo "<h1>JUGADOR 1</h1>";
	$tirada=array();
	$suma1 = 0;
	for($i=1 ;$i <6;$i++){
	$dado=rand(1,6);
	$tirada[$i] =$dado;
	$suma1 = $suma1+$dado;
	print "<img src='img/$dado.jpg' width='140'>\n";
	}
		echo "<br><h1>JUGADOR 2</h1>";
	$tirada2=array();
	$suma2 = 0;
	for($i=1 ;$i <6;$i++){
	$dado=rand(1,6);
	$tirada2[$i] =$dado;
	$suma2 = $suma2+$dado;
	print "<img src='img/$dado.jpg' width='140'>\n";
	}
	echo "<h1>RESULTADO:</h1>";
	if ($suma1>$suma2){
		print "<p>Gana el JUGADOR 1 con una puntuación de $suma1</p>";
	}else{
		if ($suma1<$suma2){
			print "<p>Gana el JUGADOR 2 con una puntuación de $suma2</p>";
		}else{
			echo "<p>Hay un empate con $suma1 puntos cada uno</p>";
		}
	}
	
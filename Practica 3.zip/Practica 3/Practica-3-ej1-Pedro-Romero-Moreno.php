﻿<meta charset="UTF-8">
<html>
<head>
<style>
fieldset{
width:650px;
border:1px blue solid;
background-color:skyblue;
}
legend{
border:1px blue solid;
background-color:white;
}
</style>
<title>Practica 3 ej1</title>
<body>
<fieldset >
<legend>Formulario</legend>
<p>Escriba el alto y ancho(0&ltnúmeros&lt=100) y mostraré un rectangulo de estrellas de ese tamaño. </p>
<form action="Practica-3-ej1-p2-Pedro-Romero-Moreno.php" method="post">
<p><b>Ancho:</b><input type="text" name="ancho" size=3></p> 
<p><b>Alto:</b><input type="text" name="alto" size=3></p>
<p><input type="submit" value="Dibujar"> <input type="reset" value="Borrar"></p>
</form>
</fieldset>
</body>
</html>
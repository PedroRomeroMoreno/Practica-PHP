﻿<?php
	//obtener datos del formulario
	$metodo= $_POST['mostrar'];
	$nombre = $_POST['nombre'];
	$telefono = $_POST['telefono'];
	$matri = $_POST['matricula'];
	$ense = $_POST['edu'];
	//control de errores
	//Comprobar si el archivo exite y si no existe 
	
	
	if ($matri == 'si'){
	if ($mostrar == 'archivo'){
	$archivo = 'datos.txt';
	if(!file_exists($archivo)) {
		fopen($archivo,'w'); 
	}
	$file= fopen($archivo,'a');
	fwrite($file,"El alumno $nombre , con teléfono $telefono , si esta matriculado en $ense".PHP_EOL);
	fclose($file);
	echo"<form method='post' action='datos.txt'>
	<input type='submit' value='Mostrar datos'>
	</form>
	";
	}else{
		if($mostrar == 'pantalla') {
			echo "El alumno $nombre , con teléfono $telefono , si esta matriculado en $ense";
		}
	}
	}else{
			if ($mostrar == 'archivo'){
	$archivo = 'datos.txt';
	if(!file_exists($archivo)) {
		fopen($archivo,'w'); 
	}
	$file= fopen($archivo,'a');
	fwrite($file,"El alumno $nombre , con teléfono $telefono , no esta matriculado en $ense".PHP_EOL);
	fclose($file);
	echo"<form method='post' action='datos.txt'>
	<input type='submit' value='Mostrar datos'>
	</form>
	";
	}else{
		if($mostrar == 'pantalla') {
			echo "El alumno $nombre , con teléfono $telefono , no esta matriculado en $ense";
		}
	}
	}
?>